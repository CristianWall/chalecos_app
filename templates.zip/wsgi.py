#!/usr/bin/env python3
"""
Archivo WSGI para desplegar en hosting con Python
"""

import sys
import os

# Agregar el directorio actual al path
sys.path.insert(0, os.path.dirname(__file__))

from app_hosting import app

if __name__ == "__main__":
    app.run()
